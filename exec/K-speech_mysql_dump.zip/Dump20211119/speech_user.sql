-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 52.79.253.253    Database: speech
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) DEFAULT NULL,
  `user_nick_name` varchar(255) DEFAULT NULL,
  `user_pass` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'cherrykang97@naver.com','강민주','alswn8972!'),(2,'bjh2754@naver.com','byun','$2a$10$PP8lGlLIfRiMYUXGSv7MEOTXUSEFDcicFUCtMMIzXazxxjHPvjs7m'),(3,'pkjeogus@gmail.com','12312415','$2a$10$GOM47jph85OxElgFFGpv2OM4HnUX25PdVAlgWCjS8YNGqWeGH/bFy'),(4,'tdj03063@naver.com','dfsfsafsadf','$2a$10$K.nA2xr4emxmRt0aF0O6YuBx/8KyS9Ssms7svqyyvA4LdpO1S/wmO'),(5,'gkgk@gk.gk','asd','$2a$10$MQKt8Anrij7pzSXXNbAfHeY.dgX8gU/y5hymIhn4F8CzEqWzEdqly'),(6,'User@gmail.com','User','$2a$10$ih2Zu3Mrr3Tkt/v6pF6Yq.58CW8gqd6JLxu2n/c3pgqp6g0.zq7R2'),(7,'test123@test.com','껄껄껄','$2a$10$DoAvYiSYavBvAJ7woetZU.UnoRmAmgMxN24wB0whSmLYF1vlAJG8S'),(8,'tkdals2317@naver.com','K-상민','$2a$10$gMPbSNR/Bj8Yxx2uBtN/Ee.GMneWGwQh7mbru4m01YxzVFXF4NB6S');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19  9:23:08
